package com.consultorio.sonrisaperfecta;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class PacientesActivity extends AppCompatActivity {
    private Button btnGuardar;
    private Spinner comboPacientesTipoID;
    private RadioButton r1, r2;
    private TextView ttvFechaNac;
    private Spinner comboEstadoCivil;
    private Spinner comboTipoTratamiento;
    private Spinner comboNivelEscolaridad;
    private EditText etxNombre;
    private EditText etxNumeroDoc;
    private EditText txtFechaCita;
    private EditText txtDireccion;
    private EditText txtTelefono;
    private EditText txtOcupacion;
    private EditText txtEmail;
    private EditText txtEPS;
    private EditText txtContacto;
    private EditText txtAntecedentes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pacientes);

        /*spiner*/
        comboPacientesTipoID =(Spinner) findViewById(R.id.spPacientesTI);


        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,
                R.array.comboPacientesTipoID, android.R.layout.simple_spinner_item);
        comboPacientesTipoID.setAdapter(adapter);

        comboEstadoCivil =(Spinner) findViewById(R.id.spinnerEstadoCivil);


        ArrayAdapter<CharSequence> adapter1 =ArrayAdapter.createFromResource(this,
                R.array.comboEstadoCivil, android.R.layout.simple_spinner_item);
        comboEstadoCivil.setAdapter(adapter1);


        comboTipoTratamiento =(Spinner) findViewById(R.id.spinnerTipoTratamiento);


        ArrayAdapter<CharSequence> adapter2 =ArrayAdapter.createFromResource(this,
                R.array.comboTipoTratamiento, android.R.layout.simple_spinner_item);
        comboTipoTratamiento.setAdapter(adapter2);

        comboNivelEscolaridad =(Spinner) findViewById(R.id.spinnerNivelEscolaridad);


        ArrayAdapter<CharSequence> adapter3 =ArrayAdapter.createFromResource(this,
                R.array.comboNivelEscolaridad, android.R.layout.simple_spinner_item);
        comboNivelEscolaridad.setAdapter(adapter3);


        /*Radio button*/
        r1=(RadioButton) findViewById(R.id.RdFem);
        r2=(RadioButton) findViewById(R.id.RdMas);
        etxNombre=findViewById(R.id.etxNombre);
        etxNumeroDoc=findViewById(R.id.NumeroDoc);
        txtFechaCita=findViewById(R.id.txtFechaCita);
        txtDireccion=findViewById(R.id.txtDireccion);
        txtTelefono=findViewById(R.id.txtTelefono);
        txtOcupacion=findViewById(R.id.txtOcupacion);
        txtEmail=findViewById(R.id.txtEmail);
        txtEPS=findViewById(R.id.txtEPS);
        txtContacto=findViewById(R.id.txtContacto);
        txtAntecedentes=findViewById(R.id.txtAntecedentes);
        ttvFechaNac=findViewById(R.id.txtFechaCita);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { guardarDatos(); }
        });
    }

    public void CalenFechaNac(View view){
            Calendar cal = Calendar.getInstance();
            int año = cal.get(Calendar.YEAR);
            int mes = cal.get(Calendar.MONTH);
            int dia = cal.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dpd = new DatePickerDialog(PacientesActivity.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    String FechaNac = year + "/" + (month + 1) + "/" + dayOfMonth;
                    ttvFechaNac.setText(FechaNac);
                }
            }, 2022, mes, dia);
            dpd.show();
        }
    private void guardarDatos() {
        boolean error = false;
        etxNombre.setError(null);
        if(etxNombre.getText().toString().isEmpty())
        {
            etxNombre.setError("Debe ingresar el nombre");
            error = true;
        }
        if(etxNumeroDoc.getText().toString().isEmpty())
        {
            etxNumeroDoc.setError("Debe ingresar su número de identificación");
            error = true;
        }
        if(txtFechaCita.getText().toString().isEmpty())
        {
            txtFechaCita.setError("Debe ingresar la fecha de la cita");
            error = true;
        }
        if(comboEstadoCivil == null)
        {
            error = true;
        }
        if(txtDireccion.getText().toString().isEmpty())
        {
            txtDireccion.setError("Debe ingresar su dirección de residencia");
            error = true;
        }
        if(txtTelefono.getText().toString().isEmpty())
        {
            txtTelefono.setError("Debe ingresar su teléfono");
            error = true;
        }
        if(txtOcupacion.getText().toString().isEmpty())
        {
            txtOcupacion.setError("Debe ingresar su ocupación");
            error = true;
        }
        if(txtEmail.getText().toString().isEmpty())
        {
            txtEmail.setError("Debe ingresar su correo electrónico");
            error = true;
        }
        if(comboNivelEscolaridad == null)
        {
            error = true;
        }
        if(txtEPS.getText().toString().isEmpty())
        {
            txtEPS.setError("Debe ingresar la EPS a la que pertenece");
            error = true;
        }
        if(txtContacto.getText().toString().isEmpty())
        {
            txtContacto.setError("Debe ingresar el número de un contacto de emergencia");
            error = true;
        }
        if(comboTipoTratamiento == null)
        {
            error = true;
        }
        if(txtAntecedentes.getText().toString().isEmpty())
        {
            txtAntecedentes.setError("Debe ingresar sus antecedentes odontológicos");
            error = true;
        }
        if (error) {
            Log.e("paciente", "Error en los datos. Por favor verifique");
            AlertDialog.Builder builder = new AlertDialog.Builder(PacientesActivity.this);
            builder.setMessage("Error en los datos. Por favor verifique").
                    setPositiveButton("Aceptar",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
            builder.show();
        }else{Intent intent = new Intent(PacientesActivity.this, TratamientoActivity.class);
            startActivity(intent);}

    }


}