package com.consultorio.sonrisaperfecta;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.content.DialogInterface;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    private Button btnPaciente;
    private TextView tvFechaCita;
    private TextView tvHoraCita;
    private Spinner combo_tipoDocumento;
    private Spinner combo_tipoProcedimientos;
    private EditText txtNombre;
    private EditText txtTelefono;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        combo_tipoDocumento =(Spinner) findViewById(R.id.idSpinnerTiposDocumento);
        txtNombre=findViewById(R.id.txtNombre);
        txtTelefono=findViewById(R.id.txtTelefono);




        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,
                R.array.combo_tipoDocumento, android.R.layout.simple_spinner_item);
        combo_tipoDocumento.setAdapter(adapter);

        combo_tipoProcedimientos =(Spinner) findViewById(R.id.spinnerTiposProcedimiento);


        ArrayAdapter<CharSequence> adapter1 =ArrayAdapter.createFromResource(this,
                R.array.combotipoProcedimientos, android.R.layout.simple_spinner_item);
        combo_tipoProcedimientos.setAdapter(adapter1);

        tvFechaCita=findViewById(R.id.txtFechaCita);
        tvHoraCita = findViewById(R.id.txtHora);
        btnPaciente = findViewById(R.id.btnRegistrar);

        };


    public void abrirCalendario(View view) {
        Calendar cal = Calendar.getInstance();
        int año = cal.get(Calendar.YEAR);
        int mes = cal.get(Calendar.MONTH);
        int dia = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dpd = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String Fecha = year + "/" + (month + 1) + "/" + dayOfMonth;
                tvFechaCita.setText(Fecha);

            }
        }, 2022, mes, dia );
        dpd.show();

    }


    public void abrirHora(View view) {
        Calendar c = Calendar.getInstance();
        int hora = c.get(Calendar.HOUR_OF_DAY);
        int min = c.get(Calendar.MINUTE);

        TimePickerDialog tpd = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                tvHoraCita.setText(hourOfDay + ":" + minute);

            }
        }, hora, min, false);
        tpd.show();

        View btnRegistrar;
        btnPaciente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarDatos();
            }
        });
    }
        private void guardarDatos() {
            boolean error = false;
            txtNombre.setError(null);
            if(txtNombre.getText().toString().isEmpty())
            {
                txtNombre.setError("Debe ingresar el nombre");
                error = true;
            }
            if(txtTelefono.getText().toString().isEmpty())
            {
                txtTelefono.setError("Debe ingresar el teléfono");
                error = true;
            }
            if(combo_tipoDocumento == null)
            {
                error = true;
            }
            if(tvFechaCita.getText().toString().isEmpty())
            {
                tvFechaCita.setError("Debe seleccionar la fecha de la cita");
                error = true;
            }
            if(tvHoraCita.getText().toString().isEmpty())
            {
                tvHoraCita.setError("Debe seleccionar la hora de la cita");
                error = true;
            }
            if (error) {
                Log.e("paciente","Error en los datos. Por favor verifique");
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Error en los datos. Por favor verifique").
                        setPositiveButton("Aceptar",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });
                builder.show();
            }else{Intent intent = new Intent(MainActivity.this, TratamientoActivity.class);
                startActivity(intent);}
            }

    public void Registrar(View view) {
        Intent registrar = new Intent(this,PacientesActivity.class);
        startActivity(registrar);
        };
    }

