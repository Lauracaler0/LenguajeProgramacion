package com.consultorio.sonrisaperfecta;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TratamientoActivity extends AppCompatActivity {
Button btnTratamiento;
Button btnBlanqueamientoDental;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tratamiento);
        btnTratamiento = findViewById(R.id.btnOrtodoncia);
        btnTratamiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TratamientoActivity.this, OrtodonciaActivity.class);
                startActivity(intent);
            }
        });
        btnBlanqueamientoDental = findViewById(R.id.btnBlanqueamiento);
        btnBlanqueamientoDental.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TratamientoActivity.this, BlanqueamientoDentalActivity.class);
                startActivity(intent);
            }
        });


    }

}