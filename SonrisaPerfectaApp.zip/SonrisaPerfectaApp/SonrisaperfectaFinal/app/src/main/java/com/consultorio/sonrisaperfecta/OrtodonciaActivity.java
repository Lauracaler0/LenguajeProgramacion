package com.consultorio.sonrisaperfecta;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OrtodonciaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ortodoncia);
    }
}